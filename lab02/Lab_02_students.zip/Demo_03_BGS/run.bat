python bgs.py
